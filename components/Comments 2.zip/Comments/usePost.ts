/* eslint-disable @typescript-eslint/no-non-null-assertion */
import { useMemo } from 'react';
import { trpc } from 'utils/trpc';

import type { ItsJustPenis } from './Types';
export const usePost = (id: string) => {
  //@ts-ignore
  const post = trpc.useQuery(['post.getById', { id }]);

  const commentsByParentId = useMemo(() => {
    if (post.data?.comments === null) return null;

    const group: { [key: string]: ItsJustPenis[] } = {};

    post.data?.comments?.forEach((x: ItsJustPenis) => {
      group[x.parentId!] ||= [];
      group[x.parentId!]?.push(x);
    });

    return group;
  }, [post.data?.comments]);

  const getReplies = (parentId: string | number): ItsJustPenis[] => {
    return commentsByParentId?.[parentId] || [];
  };

  return {
    post,
    rootComments: commentsByParentId?.['null'] || [],
    getReplies
  };
};
