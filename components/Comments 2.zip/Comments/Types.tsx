export type ItsJustPenis = {
  id: string;
  message: string;
  createdAt: Date;
  parentId: string | null;
  user: {
    id: string;
    name: string;
    image: string;
  };
  likeCount: number;
  likedByMe?: boolean;
};
