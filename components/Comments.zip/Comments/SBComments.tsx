import * as React from 'react';
import supabase from 'supabase/supaPublic';

import { Comments } from '.';
import AuthModal from './AuthModal';
import CommentsProvider from './CommentsProvider';
//import { AuthModal, Comments, CommentsProvider } from 'supabase-comments-x';

interface Props {
  slug?: string;
  id?: string;
}

const SBComments = ({ slug, id }: Props) => {
  const [modalVisible, setModalVisible] = React.useState(false);

  return (
    <div>
      <h2 className="text-center font-mono font-semibold my-8">Comments</h2>
      <CommentsProvider
        supabaseClient={supabase}
        onAuthRequested={() => setModalVisible(true)}
      >
        <AuthModal
          visible={modalVisible}
          onAuthenticate={() => setModalVisible(false)}
          onClose={() => setModalVisible(false)}
          providers={['google', 'facebook']}
        />
        <Comments topic={slug || id} />
      </CommentsProvider>
    </div>
  );
};

export default SBComments;
