import { useQuery, useQueryClient } from 'react-query';
import useApi from './useApi';

interface UsePageReactionsQuery {
  pageId: string;
  reactionType: string;
}

interface UsePageReactionsOptions {
  enabled?: boolean;
}

const usePageReactions = (
  { pageId, reactionType }: UsePageReactionsQuery,
  options: UsePageReactionsOptions = {}
) => {
  const api = useApi();
  const queryClient = useQueryClient();

  return useQuery(
    ['comment-reactions', { pageId, reactionType }],
    () => {
      return api.getCommentReactions({
        page_id: pageId,
        reaction_type: reactionType
      });
    },
    {
      staleTime: Infinity,
      enabled: options.enabled,
      onSuccess: (data) => {
        data?.forEach((pageReaction) => {
          queryClient.setQueryData(
            ['users', pageReaction.user_id],
            pageReaction.user
          );
        });
      }
    }
  );
};

export default usePageReactions;
