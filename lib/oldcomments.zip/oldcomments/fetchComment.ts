import prisma from 'lib/prisma';
import { type NextApiRequest, type NextApiResponse } from 'next';

import { refURL } from './clearUrl';
export default async function fetchComment(
  req: NextApiRequest,
  res: NextApiResponse
) {
  /*   const comments = await prisma.comment.findUnique({
    where: { slug: req.query.slug }
  }); */
  //const url = refURL(req.headers.referer);
  const comments = await prisma.comment.findMany({
    where: {
      url: req.query
    },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          image: true
        }
      }
    },
    orderBy: [{ createdAt: 'desc' }],
    take: 10
  });
  if (req.method === 'GET') {
    return res.json(
      comments.map((comment) => ({
        id: comment.id.toString(),
        message: comment.message,
        name: comment.user.name,
        image: comment.user.image,
        url: comment.url,
        createdAt: comment.createdAt.toString(),
        userId: comment.user.id
      }))
    );
  }
}
