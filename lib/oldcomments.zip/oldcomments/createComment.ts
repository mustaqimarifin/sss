import prisma from 'lib/prisma';
import { type NextApiRequest, type NextApiResponse } from 'next';
import { getSession } from 'next-auth/react';
import nextId from 'react-id-generator';

import { getSlug, getURL } from './clearUrl';

//import clearUrl, { refURL } from './clearUrl';
export default async function createComments(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const session = await getSession({ req });
  //const slug = clearUrl(req.headers.referer);
  const url = getURL(req.headers.referer);
  const slug = getSlug(req.headers.referer);
  const id = slug + nextId();
  console.log(id);
  const { message } = req.body;

  if (!session) {
    return res.status(403).send('Unauthorized');
  }

  if (req.method === 'POST') {
    const newEntry = await prisma.comment.create({
      data: {
        message,
        post: { connect: { url } },
        user: { connect: { id: session.user.id } }
      }
    });

    return res.status(200).json({
      id: newEntry.id.toString(),
      message: newEntry.message,
      name: session.user.name,
      image: session.user.image,
      url: newEntry.url,
      createdAt: newEntry.createdAt.toString()
    });
  }

  return res.send('Method not allowed.');
}
