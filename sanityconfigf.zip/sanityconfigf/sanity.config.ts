import { createConfig } from 'sanity';
import { deskTool } from 'sanity/desk';
import { markdownSchema } from 'sanity-plugin-markdown';
import schemaTypes from './lib/sanity/schemas/index';

export default createConfig({
  name: 'default',
  title: 'lee',
  projectId: process.env.SANITY_STUDIO_PROJECT_ID,
  dataset: 'production',
  plugins: [deskTool(), markdownSchema()],
  schema: {
    types: schemaTypes
  }
});
