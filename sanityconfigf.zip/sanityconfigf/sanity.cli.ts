import { createCliConfig } from 'sanity/cli';

export default createCliConfig({
  api: {
    projectId: '720o5jzr',
    dataset: 'production'
  }
});
