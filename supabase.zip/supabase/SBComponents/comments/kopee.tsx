import { Session, User } from '@supabase/supabase-js';
import supabase from 'supabase/supaPublic';
import { definitions } from 'supabase/types/supabase';

interface Props {
  slug?: string | null;
}
export const getComments = async (slug: string) => {
  const { data: comments, error } = await supabase
    .from<definitions['comments']>('comments')
    .select(`*`)
    .range(0, 9)
    .eq('slug', slug)
    .order('createdAt', { ascending: false });
  if (error) console.log('error', error);
  return comments;
};

export const createComment = async (
  parentId: any,
  user: Session,
  profile: definitions['profiles'],
  content: User | null,
  slug: any
) => {
  const newComment = {
    authorId: user?.user?.id,
    name: profile?.username,
    image: profile?.avatar_url,
    parentId: parentId || null,
    content: content,
    slug
  };
  const { data: comment } = await supabase
    .from<definitions['comments']>('comments')
    .insert([newComment])
    .single();

  return comment;
};

/* export const createComment = async (
  content: string,
  parentId = null,
  slug,
  user,
  profile
) => {
  const newComment = {
    authorId: user?.id,
    name: profile?.full_name,
    image: profile?.avatar_url,
    content,
    //sort_parent_id: sort_parent_id ?? rootId,
    parentId: parentId || null,
    slug: slug
  };
  const { data: comment } = await supabase
    .from<definitions['comments']>('comments')
    .insert([newComment])
    .single();

  return comment;
}; */
/* {
    id: comment.id,
    text: comment.text,
    name: comment.name,
    image: comment.image,
    parentId: comment.parentId,
    createdAt: comment.createdAt.toISOString()
  }; 
}; */

/* export const updateComment = async (text) => {
  return { text };
}; */

export const deleteComment = async (comment) => {
  try {
    await supabase
      .from<definitions['comments']>('comments')
      .delete()
      .eq('id', comment.id);
    return {};
  } catch (error) {
    console.log('error', error);
  }
};

/* export const getComments = async () => {
  return [
    {
      id: "1",
      body: "First comment",
      username: "Jack",
      userId: "1",
      parentId: null,
      createdAt: "2021-08-16T23:00:33.010+02:00",
    },
    {
      id: "2",
      body: "Second comment",
      username: "John",
      userId: "2",
      parentId: null,
      createdAt: "2021-08-16T23:00:33.010+02:00",
    },
    {
      id: "3",
      body: "First comment first child",
      username: "John",
      userId: "2",
      parentId: "1",
      createdAt: "2021-08-16T23:00:33.010+02:00",
    },
    {
      id: "4",
      body: "Second comment second child",
      username: "John",
      userId: "2",
      parentId: "2",
      createdAt: "2021-08-16T23:00:33.010+02:00",
    },
  ];
}; */
/*   const addComment = async (bodyText) => {
    let body = bodyText.trim();
    if (body.length) {
      let { data: comment, error } = await supabase
        .from("comments")
        .insert({ body, user_id: user.id })
        .single();
      if (error) setError(error.message);
      else setComments([...comments, comment]);
    }
  }; */
