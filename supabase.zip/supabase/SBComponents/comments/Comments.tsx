import React, { useEffect, useState } from 'react';
import { useUser } from 'supabase/hooks/useUser';
import { CommentType } from 'supabase/types/interface';

import Comment from './Comment';
import CommentForm from './CommentForm';
import {
  createComment as createCommentApi,
  deleteComment as deleteCommentApi,
  getComments as getCommentsApi
} from './kopee';

const Comments = ({ slug }) => {
  const { user, profile } = useUser();
  const [comments, setComments] = useState<any[]>([]);
  const [activeComment, setActiveComment] = useState(null);
  const rootComments = comments.filter((comment) => comment?.parentId === null);
  const getReplies = (commentId: any) =>
    comments
      .filter((comment) => comment?.parentId === commentId)
      .sort(
        (a, b) =>
          new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      );

  const addComment = (content, parentId = null, topic) => {
    createCommentApi(content, parentId, profile, user, topic).then(
      (comment) => {
        setComments([comment, ...comments]);
        setActiveComment(null);
      }
    );
  };

  const deleteComment = (commentId: any) => {
    if (window.confirm('Are you sure you want to remove comment?')) {
      deleteCommentApi(commentId).then(() => {
        const updatedComment = comments.filter(
          (comment) => comment.id !== commentId
        );
        setComments(updatedComment);
      });
    }
  };

  useEffect(() => {
    getCommentsApi(slug).then((data: any) => setComments(data));
  }, [slug]);

  return (
    <div id="supadupa" className="p-2 mt-5 w-full">
      <h3 className="font-gt mb-5 w-full text-2xl text-center">Comments</h3>
      <CommentForm
        submitLabel="Post"
        placeholder="REPLYYY"
        /* {`Reply to comment by ${comments.filter((comment) => {
            comment.author;
          })}`} */
        handleSubmit={addComment}
        autofocus={false}
      />
      <div className="overscroll-contain mt-2">
        <div className="comments-container">
          {rootComments.map((x) => (
            <Comment
              key={x.id}
              comment={x}
              replies={getReplies(x.id)}
              activeComment={activeComment}
              setActiveComment={setActiveComment}
              addComment={addComment}
              deleteComment={deleteComment}
              authorId={user?.id}
              pageIndex={undefined}
              highlight={false}
              parentId={x.id}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Comments;
