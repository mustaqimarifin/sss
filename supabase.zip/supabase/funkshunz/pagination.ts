export const PAGE_SIZE = 10;
export const SCROLL_OFFSET_PX = 400;
export const MAX_DEPTH = 10;
