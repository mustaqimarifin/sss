drop view if exists comment_with_author_votes cascade;

create
or replace view comment_with_author_votes as
select
    p.id,
    p.sort_id,
    p.sort_parent_id,
    p.name,
    p.image,
    p.slug,
    p."createdAt",
    p."updatedAt",
    p.text,
    p."authorId",
    p."parentId",
    p."author",
    coalesce (sum (v.value) over w, 0) as "votes",
    sum (
        case
            when v.value > 0 then 1
            else 0
        end
    ) over w as "upvotes",
    sum (
        case
            when v.value < 0 then 1
            else 0
        end
    ) over w as "downvotes" -- (select case when auth.uid() = v."userId" then v.value else 0 end) as "userVoteValue"
from
    comment_with_author p
    left join votes v on p.sort_id = v."combId" window w as (partition by v."combId");
    
SELECT *
FROM country, city
WHERE city.country_id = country.id;
    
SELECT *
FROM profiles
INNER JOIN comments ON comments."authorId" = profiles.id;
INNER JOIN pages ON pages.slug = comments.slug
    create view "clientComments" as
    select
        comments.id,
        profiles.username,
        profiles.avatar_url,
        comment.content,
        comment."createdAt"
        comment.slug
        courses.title,
        courses.code,
        grades.result
    from grades
    left join students on grades.student_id = students.id
    left join courses on grades.course_id = courses.id;

alter view transcripts owner to authenticated;

          id?: parameters['rowFilter.comment_with_author.id'];
          sort_id?: parameters['rowFilter.comment_with_author.sort_id'];
          sort_parent_id?: parameters['rowFilter.comment_with_author.sort_parent_id'];
          name?: parameters['rowFilter.comment_with_author.name'];
          image?: parameters['rowFilter.comment_with_author.image'];
          slug?: parameters['rowFilter.comment_with_author.slug'];
          createdAt?: parameters['rowFilter.comment_with_author.createdAt'];
          updatedAt?: parameters['rowFilter.comment_with_author.updatedAt'];
          content?: parameters['rowFilter.comment_with_author.content'];
          authorId?: parameters['rowFilter.comment_with_author.authorId'];
          parentId?: parameters['rowFilter.comment_with_author.parentId'];
          author?: parameters['rowFilter.comment_with_author.author'];