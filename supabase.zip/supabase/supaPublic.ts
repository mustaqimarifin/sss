import { createClient } from '@supabase/supabase-js';
const supabaseUrl = process.env.NEXT_PUBLIC_SUCKASS_URL;
const supabaseKey = process.env.NEXT_PUBLIC_SUCKASS;
const supabase = createClient(supabaseUrl, supabaseKey);

export default supabase;
